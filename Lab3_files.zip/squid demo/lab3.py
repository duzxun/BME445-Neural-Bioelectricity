import scipy as sp
import pylab as plt
from scipy.integrate import odeint

class SquidModel():
    GAS_CONSTANT = 8.314
    FARADAY = 9.65e4
    CELSIUS_TO_KELVIN = 273.15
    EREST_ACT = -70.0
    defaults = {
        'temperature': CELSIUS_TO_KELVIN + 6.3,
        'K_out': 10.0,
        'Na_out': 460.0,
        'K_in': 301.4,
        'Na_in': 70.96,
        'length': 500,  # um
        'diameter': 500,  # um
        'E_L': EREST_ACT + 10.613,
        'initVm': EREST_ACT,
        'specific_cm': 1.0,  # uF/cm^2
        'specific_gl': 0.3,  # mmho/cm^2
        'specific_gNa': 120.0,  # mmho/cm^2
        'specific_gK': 36.0,  # mmho/cm^2
        'runtime': 50.0,
        'simdt': 0.00001,
        'plotdt': 0.0001,
        'vclamp': 0,
        'iclamp': 1,
        'vclamp.holdingV': -70.0,
        'vclamp.delayT': 10.0,
        'vclamp.clampV': -20.0,
        'vclamp.clampT': 20.0,
        'iclamp.baseI': 0.0,
        'iclamp.firstI': 0.1,
        'iclamp.firstT': 40.0,
        'iclamp.firstD': 5.0,
        'iclamp.secondI': 0.0,
        'iclamp.secondT': 0.0,
        'iclamp.secondD': 0.0,
        'pulse':0
    }
    def __init__(self):
        self.runtime = self.defaults['runtime']
        self.rundt = self.defaults['simdt']
        self.plotdt = self.defaults['plotdt']
        self.i_clamp = self.defaults['iclamp']
        self.i_base = self.defaults['iclamp.baseI']
        self.i_first = self.defaults['iclamp.firstI']
        self.i_first_delay = self.defaults['iclamp.firstD']
        self.i_first_width = self.defaults['iclamp.firstT']
        self.i_second = self.defaults['iclamp.secondI']
        self.i_second_delay = self.defaults['iclamp.secondD']
        self.i_second_width = self.defaults['iclamp.secondT']
        self.v_clamp = self.defaults['vclamp']
        self.v_base = self.defaults['vclamp.holdingV']
        self.v_first = self.defaults['vclamp.clampV']
        self.v_first_delay = self.defaults['vclamp.delayT']
        self.v_first_width = self.defaults['vclamp.clampT']
        self.length = self.defaults['length']
        self.diameter = self.defaults['diameter']
        self.Ko = self.defaults['K_out']
        self.Ki = self.defaults['K_in']
        self.Nao = self.defaults['Na_out']
        self.Nai = self.defaults['Na_in']
        self.E_L = self.defaults['E_L']
        self.s_g_Na = self.defaults['specific_gNa']
        self.s_g_K = self.defaults['specific_gK']
        self.s_g_L = self.defaults['specific_gl']
        self.s_C_m = self.defaults['specific_cm']
        self.temp = self.defaults['temperature']
        self.pulse = self.defaults['pulse']
        self.v_init = self.defaults['initVm']
        self.vm = []
        self.ik = []
        self.ina = []
        self.iclamp_data = []
        self.gk_data = []
        self.gna_data = []
        self.m_data = []
        self.h_data = []
        self.n_data = []

    @property
    def area(self): return 1e-8 * self.length * sp.pi * self.diameter

    @property
    def C_m(self): return self.s_C_m * self.area

    @property
    def g_Na(self): return self.s_g_Na * self.area

    @property
    def g_K(self): return self.s_g_K * self.area

    @property
    def g_L(self): return self.s_g_L * self.area

    @property
    def E_Na(self): return self.GAS_CONSTANT*self.temp/self.FARADAY*1000*(sp.log(self.Nao/self.Nai)) + 70.0 + self.EREST_ACT

    @property
    def E_K(self): return self.GAS_CONSTANT * self.temp / self.FARADAY * 1000 * (sp.log(self.Ko / self.Ki)) + 70.0 + self.EREST_ACT

    #Rm = 1/(g_L * area)
    def alpha_m(self,V): return 0.1 * (V -25.0-self.EREST_ACT) / (1.0 - sp.exp(-(V -25.0-self.EREST_ACT) / 10.0))
    def beta_m(self,V):  return 4.0 * sp.exp(-(V-self.EREST_ACT) / 18.0)

    def alpha_h(self,V): return 0.07 * sp.exp(-(V-self.EREST_ACT) / 20.0)
    def beta_h(self,V):  return 1.0 / (1.0 + sp.exp(-(V -30.0-self.EREST_ACT) / 10.0))

    def alpha_n(self,V): return 0.01 * (V -10.0-self.EREST_ACT) / (1.0 - sp.exp(-(V -10.0-self.EREST_ACT) / 10.0))
    def beta_n(self,V):  return 0.125 * sp.exp(-(V-self.EREST_ACT) / 80.0)

    def I_Na(self,V, m, h): return self.g_Na * m ** 3 * h * (V - self.E_Na)

    def I_K(self,V, n):  return self.g_K * n ** 4 * (V - self.E_K)

    def I_L(self,V):    return self.g_L * (V - self.E_L)

    def I_inj(self, t, V, I_inh):  # step up 10 uA/cm^2 every 100ms for 400ms
        if self.i_clamp:
            if self.pulse:
                period = self.i_first_delay + self.i_first_width + self.i_second_delay + self.i_second_width
                t = t % period
            i_first = self.i_first - self.i_base
            i_second = self.i_second - self.i_base
            x = self.i_base + i_first*(t>self.i_first_delay) - i_first*(t>(self.i_first_delay+self.i_first_width))\
            + i_second*(t>(self.i_first_delay+self.i_first_width + self.i_second_delay)) \
	    - i_second*(t>(self.i_first_delay+ self.i_first_width + self.i_second_delay + self.i_second_width))
        else:
            v_first = self.v_first - self.v_base
            v_g = self.v_base + v_first*(t>self.v_first_delay) - v_first*(t>(self.v_first_delay+self.v_first_width))
            x = 25*self.C_m*(v_g - V) + I_inh
        return x

    def dALLdt(self,X, t):
        V, m, h, n = X
        I_inh = self.I_Na(V, m, h) + self.I_K(V, n) + self.I_L(V)
        # calculate membrane potential & activation variables
        dVdt = 1/self.C_m * (self.I_inj(t, V, I_inh) - I_inh)
        dmdt = self.alpha_m(V) * (1.0 - m) - self.beta_m(V) * m
        dhdt = self.alpha_h(V) * (1.0 - h) - self.beta_h(V) * h
        dndt = self.alpha_n(V) * (1.0 - n) - self.beta_n(V) * n
        return dVdt, dmdt, dhdt, dndt

    def run(self, runtime):
        t = sp.arange(0.0, runtime, self.rundt)
        t_plot = sp.arange(0.0, runtime, self.plotdt)
        X = odeint(self.dALLdt, [self.v_init, 0.05, 0.6, 0.32], t)
        sample = int(round(self.plotdt/self.rundt))
        self.vm = X[:, 0][::sample]
        self.m_data = X[:, 1][::sample]
        self.h_data = X[:, 2][::sample]
        self.n_data = X[:, 3][::sample]
        self.ina = self.I_Na(self.vm, self.m_data, self.h_data)
        self.ik = self.I_K(self.vm, self.n_data)
        self.il = self.I_L(self.vm)
        inh = self.ina + self.ik + self.il
        self.iclamp = self.I_inj(t_plot, self.vm, inh)
        self.gna_data = self.g_Na * self.m_data ** 3 * self.h_data
        self.gk_data = self.g_K * self.n_data**4

if __name__ == '__main__':

    model = SquidModel()
    model.run(50)
    t_plot = sp.arange(0.0, model.runtime, model.plotdt)
    plt.figure()

    plt.subplot(4, 1, 1)
    plt.title('Hodgkin-Huxley Neuron')
    plt.plot(t_plot, model.vm, 'k')
    plt.ylabel('V (mV)')

    plt.subplot(4, 1, 2)
    plt.plot(t_plot, model.ina, 'c', label='$I_{Na}$')
    plt.plot(t_plot, model.ik, 'y', label='$I_{K}$')
    plt.plot(t_plot, model.il, 'm', label='$I_{L}$')
    plt.ylabel('Current')
    plt.legend()

    plt.subplot(4, 1, 3)
    plt.plot(t_plot, model.m_data, 'r', label='m')
    plt.plot(t_plot, model.h_data, 'g', label='h')
    plt.plot(t_plot, model.n_data, 'b', label='n')
    plt.ylabel('Gating Value')
    plt.legend()

    plt.subplot(4, 1, 4)
    plt.plot(t_plot, model.iclamp, 'k')
    plt.xlabel('t (ms)')
    plt.ylabel('$I_{inj}$ ($\\mu{A}/cm^2$)')
    plt.show()
